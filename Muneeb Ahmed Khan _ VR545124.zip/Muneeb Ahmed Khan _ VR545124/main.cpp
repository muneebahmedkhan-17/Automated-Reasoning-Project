#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "parser.h"
#include "solver.h"

// Reads the input file (one constraint per line), parses it, executes the solver, and outputs SAT/UNSAT.
int main(int argc, char** argv) {
    if (argc != 2) {
        std::cout << "Usage: solver.exe <input_file>\n";
        return 1;
    }

    std::ifstream in(argv[1]);
    if (!in) {
        std::cout << "Error: cannot open file\n";
        return 1;
    }

    std::vector<Literal> S;
    std::string line;
    int lineNo = 0;

    while (std::getline(in, line)) {
        lineNo++;
        std::string t = trim(line);
        if (t.empty()) continue;
        if (starts_with(t, "#")) continue;
        if (starts_with(t, "//")) continue;

        try {
            auto tks = tokenize(t);
            Parser p{tks};
            S.push_back(p.parseLiteral());
        } catch (const std::exception& e) {
            std::cout << "ERR line " << lineNo << ": " << e.what() << "\n";
            std::cout << "  line: " << t << "\n";
            return 1;
        }
    }

    bool sat = solve_problem(std::move(S));
    std::cout << (sat ? "SAT\n" : "UNSAT\n");
    return 0;
}
