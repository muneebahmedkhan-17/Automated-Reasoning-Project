#include "parser.h"
#include <cctype>
#include <stdexcept>

// Tokenizer and parser for solver input: creates Term/Literal AST nodes by parsing one literal per line.
std::string trim(const std::string& s) {
    size_t a = 0;
    while (a < s.size() && std::isspace((unsigned char)s[a])) a++;
    size_t b = s.size();
    while (b > a && std::isspace((unsigned char)s[b - 1])) b--;
    return s.substr(a, b - a);
}
bool starts_with(const std::string& s, const std::string& pfx) {
    return s.rfind(pfx, 0) == 0;
}

std::vector<Token> tokenize(const std::string& s) {
    std::vector<Token> tks;
    size_t i = 0;
    auto push = [&](TokKind k, const std::string& txt) { tks.push_back({k, txt}); };

    while (i < s.size()) {
        char c = s[i];
        if (std::isspace((unsigned char)c)) { i++; continue; }

        if (std::isalpha((unsigned char)c) || c == '_') {
            size_t j = i + 1;
            while (j < s.size()) {
                char d = s[j];
                if (std::isalnum((unsigned char)d) || d == '_') j++;
                else break;
            }
            push(TokKind::Ident, s.substr(i, j - i));
            i = j;
            continue;
        }

        if (c == '(') { push(TokKind::LParen, "("); i++; continue; }
        if (c == ')') { push(TokKind::RParen, ")"); i++; continue; }
        if (c == ',') { push(TokKind::Comma, ","); i++; continue; }
        if (c == '=') { push(TokKind::Eq, "="); i++; continue; }

        if (c == '!') {
            if (i + 1 < s.size() && s[i + 1] == '=') { push(TokKind::Neq, "!="); i += 2; continue; }
            push(TokKind::Not, "!");
            i++;
            continue;
        }

        throw std::runtime_error(std::string("Tokenizer: unexpected char: ") + c);
    }

    push(TokKind::End, "");
    return tks;
}


const Token& Parser::cur() const { return tks[pos]; }
bool Parser::at(TokKind k) const { return cur().kind == k; }
void Parser::eat(TokKind k, const char* msg) { if (!at(k)) throw std::runtime_error(msg); pos++; }

Term Parser::parseTerm() {
    if (!at(TokKind::Ident)) throw std::runtime_error("Parser: expected identifier");
    Term t; t.name = cur().text; pos++;

    if (at(TokKind::LParen)) {
        eat(TokKind::LParen, "Parser: expected '('");
        t.args.push_back(parseTerm());
        while (at(TokKind::Comma)) {
            eat(TokKind::Comma, "Parser: expected ','");
            t.args.push_back(parseTerm());
        }
        eat(TokKind::RParen, "Parser: expected ')'");
    }
    return t;
}

Literal Parser::parseLiteral() {
    bool neg = false;
    if (at(TokKind::Not)) { neg = true; eat(TokKind::Not, "Parser: expected '!'"); }

    // atom(t) or !atom(t)
    if (at(TokKind::Ident) && cur().text == "atom") {
        Term atf = parseTerm(); // atom(arg)
        if (atf.name != "atom" || atf.args.size() != 1)
            throw std::runtime_error("Parser: atom must be unary: atom(t)");
        eat(TokKind::End, "Parser: extra tokens at end");
        Literal L;
        L.kind = neg ? LitKind::AtomNeg : LitKind::AtomPos;
        L.lhs = atf.args[0];
        return L;
    }

    if (neg) throw std::runtime_error("Parser: '!' is only allowed as !atom(t)");

    // equality / disequality
    Literal L;
    L.lhs = parseTerm();

    if (at(TokKind::Eq)) { eat(TokKind::Eq, "Parser: expected '='"); L.kind = LitKind::Eq; }
    else if (at(TokKind::Neq)) { eat(TokKind::Neq, "Parser: expected '!='"); L.kind = LitKind::Neq; }
    else throw std::runtime_error("Parser: expected '=' or '!='");

    L.rhs = parseTerm();
    eat(TokKind::End, "Parser: extra tokens at end");
    return L;
}
