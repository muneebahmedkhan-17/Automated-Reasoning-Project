#pragma once
#include <string>
#include <vector>

// Types of tokens for the small input language.
enum class TokKind { Ident, LParen, RParen, Comma, Eq, Neq, Not, End };
struct Token { TokKind kind; std::string text; };

// Minimal AST used by the solver.
struct Term { std::string name; std::vector<Term> args; };

enum class LitKind { Eq, Neq, AtomPos, AtomNeg };

struct Literal {
    LitKind kind = LitKind::Eq;
    Term lhs;
    Term rhs;
};

// Small helpers for reading/parsing input lines.
std::string trim(const std::string& s);
bool starts_with(const std::string& s, const std::string& pfx);

// Lex one line into tokens.
std::vector<Token> tokenize(const std::string& s);

// Parses a single line into one Literal.
struct Parser {
    const std::vector<Token>& tks;
    size_t pos = 0;

    const Token& cur() const;
    bool at(TokKind k) const;
    void eat(TokKind k, const char* msg);

    Term parseTerm();
    Literal parseLiteral();
};
