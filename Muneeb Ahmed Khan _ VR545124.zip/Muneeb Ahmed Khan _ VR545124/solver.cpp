#include "solver.h"

#include <string>
#include <vector>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>
#include <deque>
#include <algorithm>
#include <cstdint>
#include <memory>

// Structural equality check for terms (same symbol and same arguments)
static bool term_eq(const Term& a, const Term& b) {
    if (a.name != b.name) return false;
    if (a.args.size() != b.args.size()) return false;
    for (size_t i = 0; i < a.args.size(); i++) if (!term_eq(a.args[i], b.args[i])) return false;
    return true;
}

// Converts a term to a compact string form for hashing/de-dup.
static std::string term_to_string(const Term& t) {
    if (t.args.empty()) return t.name;
    std::string out = t.name;
    out.push_back('(');
    for (size_t i = 0; i < t.args.size(); i++) {
        if (i) out.push_back(',');
        out += term_to_string(t.args[i]);
    }
    out.push_back(')');
    return out;
}

static std::string lit_to_string(const Literal& L) {
    if (L.kind == LitKind::Eq)  return term_to_string(L.lhs) + "="  + term_to_string(L.rhs);
    if (L.kind == LitKind::Neq) return term_to_string(L.lhs) + "!=" + term_to_string(L.rhs);
    if (L.kind == LitKind::AtomPos) return "atom(" + term_to_string(L.lhs) + ")";
    return "!atom(" + term_to_string(L.lhs) + ")";
}

static std::string state_key(const std::vector<Literal>& S) {
    std::vector<std::string> v;
    v.reserve(S.size());
    for (const auto& L : S) v.push_back(lit_to_string(L));
    std::sort(v.begin(), v.end());
    std::string out;
    out.reserve(v.size() * 16);
    for (const auto& s : v) { out += s; out.push_back(';'); }
    return out;
}

// Identifies instantaneous contradictions, such as x != x.
static bool has_trivial_contradiction(const std::vector<Literal>& S) {
    for (const auto& L : S) {
        if (L.kind == LitKind::Neq && term_eq(L.lhs, L.rhs))
            return true; // x != x
    }
    return false;
}

// Term interning: each unique (symbol, args) is stored once and is referred to by an integer id.
struct NodeKey {
    std::string sym;
    std::vector<int> args;
    bool operator==(const NodeKey& o) const { return sym == o.sym && args == o.args; }
};
struct NodeKeyHash {
    size_t operator()(const NodeKey& k) const noexcept {
        size_t h = std::hash<std::string>{}(k.sym);
        for (int a : k.args) h ^= (std::hash<int>{}(a) + 0x9e3779b9 + (h << 6) + (h >> 2));
        return h;
    }
};
struct Node { std::string sym; std::vector<int> args; };

struct TermDB {
    std::unordered_map<NodeKey, int, NodeKeyHash> memo;
    std::vector<Node> nodes;

    int intern(const Term& t) {
        std::vector<int> childIds;
        childIds.reserve(t.args.size());
        for (const auto& a : t.args) childIds.push_back(intern(a));

        NodeKey key{ t.name, childIds };
        auto it = memo.find(key);
        if (it != memo.end()) return it->second;

        int id = (int)nodes.size();
        nodes.push_back(Node{ t.name, childIds });
        memo.emplace(std::move(key), id);
        return id;
    }

    int make_node(const std::string& sym, const std::vector<int>& args) {
        NodeKey key{ sym, args };
        auto it = memo.find(key);
        if (it != memo.end()) return it->second;

        int id = (int)nodes.size();
        nodes.push_back(Node{ sym, args });
        memo.emplace(std::move(key), id);
        return id;
    }

    int make_select(int arr, int idx) { return make_node("select", {arr, idx}); }
    int make_car(int x) { return make_node("car", {x}); }
    int make_cdr(int x) { return make_node("cdr", {x}); }
};

// Congruence closure with the signature table; during merges, signatures are refreshed to prevent stale matches.
struct SigKey {
    std::string sym;
    std::vector<int> argReps;
    bool operator==(const SigKey& o) const { return sym == o.sym && argReps == o.argReps; }
};
struct SigHash {
    size_t operator()(const SigKey& k) const noexcept {
        size_t h = std::hash<std::string>{}(k.sym);
        for (int a : k.argReps) h ^= (std::hash<int>{}(a) + 0x9e3779b9 + (h << 6) + (h >> 2));
        return h;
    }
};

struct CC {
    TermDB& db;
    std::vector<int> parent;
    std::vector<std::vector<int>> ccpar;
    std::unordered_map<SigKey, int, SigHash> sig;
    std::deque<int> q;

    CC(TermDB& db_) : db(db_) { ensure_size(); build_initial(); }

    void ensure_size() {
        int n = (int)db.nodes.size();
        while ((int)parent.size() < n) {
            int id = (int)parent.size();
            parent.push_back(id);
            ccpar.push_back({});
        }
    }

    int find(int x) {
        if (parent[x] == x) return x;
        parent[x] = find(parent[x]);
        return parent[x];
    }

    SigKey make_key(int id) {
        const Node& node = db.nodes[id];
        SigKey k;
        k.sym = node.sym;
        k.argReps.reserve(node.args.size());
        for (int a : node.args) k.argReps.push_back(find(a));
        return k;
    }

    void add_parent_links_for_node(int id) {
        const Node& node = db.nodes[id];
        if (node.args.empty()) return;
        for (int a : node.args) ccpar[find(a)].push_back(id);
    }

    void enqueue(int id) { q.push_back(id); }

    static void dedup_vec(std::vector<int>& v) {
        if (v.size() < 2) return;
        std::sort(v.begin(), v.end());
        v.erase(std::unique(v.begin(), v.end()), v.end());
    }

    void process_one(int id) {
        const Node& node = db.nodes[id];
        if (node.args.empty()) return;

        SigKey key = make_key(id);
        while (true) {
            auto it = sig.find(key);
            if (it == sig.end()) {
                sig.emplace(std::move(key), id);
                return;
            }

            int other = it->second;
            if (other == id) return;

            SigKey otherKey = make_key(other);

            if (!(otherKey == key)) {
                it->second = id;
                return;
            }

            if (!unite(id, other)) return;

            key = make_key(id);
            auto it2 = sig.find(key);
            if (it2 != sig.end()) it2->second = id;
        }
    }

    void drain_queue() {
        while (!q.empty()) {
            int id = q.front(); q.pop_front();
            if (id < 0 || id >= (int)db.nodes.size()) continue;
            process_one(id);
        }
    }

    void build_initial() {
        sig.clear();
        for (int i = 0; i < (int)db.nodes.size(); i++) add_parent_links_for_node(i);
        for (int i = 0; i < (int)db.nodes.size(); i++) enqueue(i);
        drain_queue();
        for (auto& v : ccpar) dedup_vec(v);
    }

    void on_new_nodes(int oldN) {
        ensure_size();
        for (int i = oldN; i < (int)db.nodes.size(); i++) {
            add_parent_links_for_node(i);
            enqueue(i);
        }
        drain_queue();
        for (auto& v : ccpar) dedup_vec(v);
    }

    bool unite(int a, int b) {
        a = find(a); b = find(b);
        if (a == b) return false;

        if (ccpar[a].size() < ccpar[b].size()) std::swap(a, b);
        parent[b] = a;

        auto& Va = ccpar[a];
        auto& Vb = ccpar[b];
        Va.insert(Va.end(), Vb.begin(), Vb.end());
        Vb.clear();
        dedup_vec(Va);

        for (int p : Va) enqueue(p);
        drain_queue();
        return true;
    }
};

// Utility routines for local Abstract Syntax Tree rewrites and store/select term detection and collection.
struct StoreInfoAST { Term A, i, x; };

static bool term_has_store(const Term& t) {
    if (t.name == "store" && t.args.size() == 3) return true;
    for (const auto& a : t.args) if (term_has_store(a)) return true;
    return false;
}

static void collect_store_terms(const Term& t, std::vector<Term>& stores) {
    if (t.name == "store" && t.args.size() == 3) stores.push_back(t);
    for (const auto& a : t.args) collect_store_terms(a, stores);
}

static void collect_select_reads(const Term& t, std::vector<Term>& selects) {
    if (t.name == "select" && t.args.size() == 2) selects.push_back(t);
    for (const auto& a : t.args) collect_select_reads(a, selects);
}

static bool is_select_term(const Term& t) { return t.name == "select" && t.args.size() == 2; }

static Term mk_const_term(const std::string& n) { Term t; t.name = n; return t; }
static Term mk_select_term(const Term& arr, const Term& idx) { Term t; t.name="select"; t.args={arr,idx}; return t; }
static Term mk_cons_term(const Term& a, const Term& b) { Term t; t.name="cons"; t.args={a,b}; return t; }

static Literal mk_eq(const Term& a, const Term& b) { return Literal{LitKind::Eq, a, b}; }
static Literal mk_neq(const Term& a, const Term& b) { return Literal{LitKind::Neq, a, b}; }

static Term replace_exact(const Term& t, const Term& from, const Term& to) {
    if (term_eq(t, from)) return to;
    if (t.args.empty()) return t;
    Term out;
    out.name = t.name;
    out.args.reserve(t.args.size());
    for (const auto& a : t.args) out.args.push_back(replace_exact(a, from, to));
    return out;
}

static void replace_in_literals(std::vector<Literal>& S, const Term& from, const Term& to) {
    for (auto& L : S) {
        if (L.kind == LitKind::Eq || L.kind == LitKind::Neq) {
            L.lhs = replace_exact(L.lhs, from, to);
            L.rhs = replace_exact(L.rhs, from, to);
        } else {
            L.lhs = replace_exact(L.lhs, from, to);
        }
    }
}

static bool literal_has_store(const Literal& L) {
    if (L.kind == LitKind::Eq || L.kind == LitKind::Neq)
        return term_has_store(L.lhs) || term_has_store(L.rhs);
    return term_has_store(L.lhs);
}

static bool has_literal_eq_or_neq(const std::vector<Literal>& S, const Term& a, const Term& b, bool wantEq) {
    for (const auto& L : S) {
        if (wantEq && L.kind == LitKind::Eq) {
            if ((term_eq(L.lhs,a) && term_eq(L.rhs,b)) || (term_eq(L.lhs,b) && term_eq(L.rhs,a))) return true;
        }
        if (!wantEq && L.kind == LitKind::Neq) {
            if ((term_eq(L.lhs,a) && term_eq(L.rhs,b)) || (term_eq(L.lhs,b) && term_eq(L.rhs,a))) return true;
        }
    }
    return false;
}
static bool has_neq_lit(const std::vector<Literal>& S, const Term& a, const Term& b) {
    return has_literal_eq_or_neq(S, a, b, false);
}

// By adding new array variables and restrictions for the written index, store(...) is eliminated.
static std::unordered_map<std::string, StoreInfoAST> eliminate_stores(std::vector<Literal>& S) {
    std::vector<Term> stores;
    for (const auto& L : S) {
        if (L.kind == LitKind::Eq || L.kind == LitKind::Neq) {
            collect_store_terms(L.lhs, stores);
            collect_store_terms(L.rhs, stores);
        } else {
            collect_store_terms(L.lhs, stores);
        }
    }

    std::vector<Term> uniq;
    for (const auto& st : stores) {
        bool seen = false;
        for (const auto& u : uniq) if (term_eq(st, u)) { seen = true; break; }
        if (!seen) uniq.push_back(st);
    }

    std::unordered_map<std::string, StoreInfoAST> storeMap;
    int k = 0;
    for (const auto& st : uniq) {
        Term A = st.args[0];
        Term i = st.args[1];
        Term x = st.args[2];

        std::string Bname = "_st" + std::to_string(k++);
        Term B = mk_const_term(Bname);

        replace_in_literals(S, st, B);
        S.push_back(mk_eq(mk_select_term(B, i), x));

        storeMap.emplace(Bname, StoreInfoAST{A, i, x});
    }

    return storeMap;
}

// Determines which new store-arrays correspond to which CC class after building congruence closure using only equality literals.
struct CCBuild {
    TermDB db;
    std::unique_ptr<CC> cc;
    std::unordered_map<std::string, int> bId;
    std::unordered_map<int, std::string> repToBname;
};

static CCBuild build_cc_equalities_only(
    const std::vector<Literal>& S,
    const std::unordered_map<std::string, StoreInfoAST>& storeMap
) {
    CCBuild build;

    for (const auto& L : S) {
        build.db.intern(L.lhs);
        if (L.kind == LitKind::Eq || L.kind == LitKind::Neq) build.db.intern(L.rhs);
    }

    for (const auto& kv : storeMap) {
        Term B = mk_const_term(kv.first);
        int id = build.db.intern(B);
        build.bId[kv.first] = id;
    }

    build.cc = std::make_unique<CC>(build.db);

    for (const auto& L : S) {
        if (L.kind != LitKind::Eq) continue;
        int a = build.db.intern(L.lhs);
        int b = build.db.intern(L.rhs);
        build.cc->unite(a, b);
    }

    for (const auto& kv : build.bId) {
        int rep = build.cc->find(kv.second);
        if (!build.repToBname.count(rep)) build.repToBname.emplace(rep, kv.first);
    }

    return build;
}

// Make It Easy Choose a (i = j) case to divide when it's still unclear, and use CC equalities to select overstore.
static Term rewrite_selects_term_cc(
    const Term& t,
    const std::unordered_map<std::string, StoreInfoAST>& storeMap,
    const std::vector<Literal>& S,
    CCBuild& build,
    bool& changed
) {
    if (is_select_term(t)) {
        const Term& arr = t.args[0];
        const Term& j   = t.args[1];

        int arrId = build.db.intern(arr);
        int repArr = build.cc->find(arrId);

        auto itB = build.repToBname.find(repArr);
        if (itB != build.repToBname.end()) {
            const std::string& Bname = itB->second;
            const StoreInfoAST& info = storeMap.at(Bname);

            int iId = build.db.intern(info.i);
            int jId = build.db.intern(j);

            if (build.cc->find(iId) == build.cc->find(jId)) {
                changed = true;
                return info.x;
            }

            if (has_neq_lit(S, info.i, j)) {
                changed = true;
                return mk_select_term(info.A, j);
            }
        }
    }

    if (t.args.empty()) return t;
    Term out;
    out.name = t.name;
    out.args.reserve(t.args.size());
    for (const auto& a : t.args) out.args.push_back(rewrite_selects_term_cc(a, storeMap, S, build, changed));
    return out;
}

static void select_elimination_phase_cc(
    std::vector<Literal>& S,
    const std::unordered_map<std::string, StoreInfoAST>& storeMap
) {
    while (true) {
        CCBuild build = build_cc_equalities_only(S, storeMap);
        bool changed = false;

        for (auto& L : S) {
            L.lhs = rewrite_selects_term_cc(L.lhs, storeMap, S, build, changed);
            if (L.kind == LitKind::Eq || L.kind == LitKind::Neq) {
                L.rhs = rewrite_selects_term_cc(L.rhs, storeMap, S, build, changed);
            }
        }

        if (!changed) break;
    }
}

static bool find_store_read_branchpoint_cc(
    const std::vector<Literal>& S,
    const std::unordered_map<std::string, StoreInfoAST>& storeMap,
    CCBuild& build,
    std::string& outBname,
    Term& outJ
) {
    for (const auto& L : S) {
        std::vector<Term> selects;
        collect_select_reads(L.lhs, selects);
        if (L.kind == LitKind::Eq || L.kind == LitKind::Neq) collect_select_reads(L.rhs, selects);

        for (const auto& sel : selects) {
            const Term& arr = sel.args[0];
            const Term& j   = sel.args[1];

            int arrId = build.db.intern(arr);
            int repArr = build.cc->find(arrId);

            auto itB = build.repToBname.find(repArr);
            if (itB == build.repToBname.end()) continue;

            const std::string& Bname = itB->second;
            const StoreInfoAST& info = storeMap.at(Bname);

            int iId = build.db.intern(info.i);
            int jId = build.db.intern(j);

            if (build.cc->find(iId) == build.cc->find(jId)) continue;

            if (has_literal_eq_or_neq(S, info.i, j, true)) continue;
            if (has_literal_eq_or_neq(S, info.i, j, false)) continue;

            outBname = Bname;
            outJ = j;
            return true;
        }
    }
    return false;
}

// Splits on unknown read-over-write scenarios (i=j vs i!=j) and removes store(...) while deduplicating states.
static std::deque<std::vector<Literal>> store_phase_make_subproblems(std::vector<Literal> S) {
    auto storeMap = eliminate_stores(S);

    for (const auto& L : S) {
        if (literal_has_store(L))
            throw std::runtime_error("BUG: store elimination failed; store(...) remains.");
    }

    std::deque<std::vector<Literal>> q;
    q.push_back(std::move(S));

    std::deque<std::vector<Literal>> out;

    std::unordered_set<std::string> seen;
    seen.reserve(4096);

    while (!q.empty()) {
        auto cur = std::move(q.front());
        q.pop_front();

        std::string key1 = state_key(cur);
        if (seen.count(key1)) continue;
        seen.insert(key1);

        select_elimination_phase_cc(cur, storeMap);

        if (has_trivial_contradiction(cur)) {
            continue;
        }

        std::string key2 = state_key(cur);
        if (key2 != key1) {
            if (seen.count(key2)) continue;
            seen.insert(std::move(key2));
        }

        CCBuild build = build_cc_equalities_only(cur, storeMap);

        std::string Bname;
        Term j;
        if (find_store_read_branchpoint_cc(cur, storeMap, build, Bname, j)) {
            const StoreInfoAST& info = storeMap.at(Bname);

            auto S1 = cur;
            auto S2 = cur;
            S1.push_back(mk_eq(info.i, j));
            S2.push_back(mk_neq(info.i, j));

            q.push_back(std::move(S1));
            q.push_back(std::move(S2));
            continue;
        }

        out.push_back(std::move(cur));
    }

    return out;
}

// Removes select(...) by assigning a new variable to each (array, index) equivalency-class pair.
struct PairKey {
    int a, b;
    bool operator==(const PairKey& o) const { return a == o.a && b == o.b; }
};
struct PairHash {
    size_t operator()(const PairKey& k) const noexcept {
        size_t h1 = std::hash<int>{}(k.a);
        size_t h2 = std::hash<int>{}(k.b);
        return h1 ^ (h2 + 0x9e3779b9 + (h1 << 6) + (h1 >> 2));
    }
};

static void build_cc_equalities_only_no_storemap(const std::vector<Literal>& S, TermDB& db, std::unique_ptr<CC>& cc) {
    for (const auto& L : S) {
        db.intern(L.lhs);
        if (L.kind == LitKind::Eq || L.kind == LitKind::Neq) db.intern(L.rhs);
    }
    cc = std::make_unique<CC>(db);
    for (const auto& L : S) {
        if (L.kind == LitKind::Eq) {
            int a = db.intern(L.lhs);
            int b = db.intern(L.rhs);
            cc->unite(a, b);
        }
    }
}

static Term replace_selects_with_fresh(
    const Term& t,
    TermDB& db,
    CC& cc,
    std::unordered_map<PairKey, Term, PairHash>& memo,
    int& fresh
) {
    if (t.name == "select" && t.args.size() == 2) {
        int arrId = db.intern(t.args[0]);
        int idxId = db.intern(t.args[1]);
        int rA = cc.find(arrId);
        int rI = cc.find(idxId);

        PairKey key{ rA, rI };
        auto it = memo.find(key);
        if (it != memo.end()) return it->second;

        Term v;
        v.name = "_sel" + std::to_string(fresh++);
        memo.emplace(key, v);
        return v;
    }

    if (t.args.empty()) return t;
    Term out;
    out.name = t.name;
    out.args.reserve(t.args.size());
    for (const auto& a : t.args) out.args.push_back(replace_selects_with_fresh(a, db, cc, memo, fresh));
    return out;
}

static void select_phase_process_away(std::vector<Literal>& S) {
    TermDB db;
    std::unique_ptr<CC> cc;
    build_cc_equalities_only_no_storemap(S, db, cc);

    std::unordered_map<PairKey, Term, PairHash> memo;
    memo.reserve(1024);
    int fresh = 0;

    for (auto& L : S) {
        L.lhs = replace_selects_with_fresh(L.lhs, db, *cc, memo, fresh);
        if (L.kind == LitKind::Eq || L.kind == LitKind::Neq)
            L.rhs = replace_selects_with_fresh(L.rhs, db, *cc, memo, fresh);
    }
}

// Cons/atom theory solver: applies car/cdr constraints for cons terms, verifies disequalities, and performs congruence closure.
struct NeqPair { int a, b; };

static bool check_diseq_contradiction(CC& cc, const std::vector<NeqPair>& neqs) {
    for (const auto& p : neqs) if (cc.find(p.a) == cc.find(p.b)) return true;
    return false;
}

static void preprocess_not_atom(std::vector<Literal>& S) {
    int fresh = 0;
    std::vector<Literal> keep;
    keep.reserve(S.size() + 8);

    for (const auto& L : S) {
        if (L.kind != LitKind::AtomNeg) { keep.push_back(L); continue; }

        Term u = L.lhs;
        Term u1{ "_na" + std::to_string(fresh++), {} };
        Term u2{ "_na" + std::to_string(fresh++), {} };
        Term consT = mk_cons_term(u1, u2);

        keep.push_back(mk_eq(u, consT));
    }

    S.swap(keep);
}

static bool tcons_projection_closure(CC& cc, TermDB& db, std::unordered_set<int>& doneCons) {
    bool changed = false;

    for (int n = 0; n < (int)db.nodes.size(); n++) {
        const Node& nd = db.nodes[n];
        if (!(nd.sym == "cons" && nd.args.size() == 2)) continue;
        if (doneCons.count(n)) continue;
        doneCons.insert(n);

        int oldN = (int)db.nodes.size();
        int carN = db.make_car(n);
        int cdrN = db.make_cdr(n);
        if ((int)db.nodes.size() != oldN) cc.on_new_nodes(oldN);

        if (cc.unite(carN, nd.args[0])) changed = true;
        if (cc.unite(cdrN, nd.args[1])) changed = true;
    }

    return changed;
}

static bool atom_consistency_ok(CC& cc, TermDB& db, const std::vector<int>& atomPos) {
    std::vector<uint8_t> st(db.nodes.size(), 0);

    auto mark = [&](int id, uint8_t v)->bool {
        int r = cc.find(id);
        uint8_t& cur = st[r];
        if (cur == 0) { cur = v; return true; }
        return cur == v;
    };

    for (int id : atomPos) if (!mark(id, 1)) return false;

    for (int n = 0; n < (int)db.nodes.size(); n++) {
        const Node& nd = db.nodes[n];
        if (nd.sym == "cons" && nd.args.size() == 2) {
            if (!mark(n, 2)) return false;
        }
    }

    return true;
}

static bool solve_Tcons_TE(std::vector<Literal> S) {
    preprocess_not_atom(S);

    TermDB db;
    std::vector<NeqPair> neqs;
    std::vector<int> atomPos;

    struct LitId { LitKind kind; int a; int b; };
    std::vector<LitId> lits;
    lits.reserve(S.size());

    for (const auto& L : S) {
        if (L.kind == LitKind::Eq || L.kind == LitKind::Neq) {
            int a = db.intern(L.lhs);
            int b = db.intern(L.rhs);
            lits.push_back({L.kind, a, b});
        } else {
            int a = db.intern(L.lhs);
            lits.push_back({L.kind, a, -1});
        }
    }

    CC cc(db);

    for (const auto& Li : lits) {
        if (Li.kind == LitKind::Eq) cc.unite(Li.a, Li.b);
        else if (Li.kind == LitKind::Neq) neqs.push_back({Li.a, Li.b});
        else if (Li.kind == LitKind::AtomPos) atomPos.push_back(Li.a);
    }

    if (check_diseq_contradiction(cc, neqs)) return false;
    if (!atom_consistency_ok(cc, db, atomPos)) return false;

    std::unordered_set<int> doneCons;
    doneCons.reserve(db.nodes.size() * 2);

    while (true) {
        bool changed = false;

        if (tcons_projection_closure(cc, db, doneCons)) changed = true;
        if (check_diseq_contradiction(cc, neqs)) return false;
        if (!atom_consistency_ok(cc, db, atomPos)) return false;

        if (!changed) break;
    }

    return true;
}

// Runs the preprocessing phases and checks satisfiability by solving each generated branch.

bool solve_problem(std::vector<Literal> S) {
    auto subs = store_phase_make_subproblems(std::move(S));

    for (auto& Si : subs) {
        select_phase_process_away(Si);
        if (has_trivial_contradiction(Si)) continue;
        if (solve_Tcons_TE(std::move(Si))) return true;
    }
    return false;
}
