#pragma once
#include <vector>
#include "parser.h"

bool solve_problem(std::vector<Literal> S);
